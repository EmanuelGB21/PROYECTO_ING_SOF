


<?php $__env->startSection('CONTENIDO'); ?>
    <div class="container p-5 text-center">
        <h6 class="mb-3">No existe esta cuenta de usuario</h6>

        <button class="btn btn-primary btn-sm" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"><i class="fas fa-arrow-left"></i> Regresar a la página principal</button>
            
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantillas_Generales.plantilla_general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/ERROR/error_acceso.blade.php ENDPATH**/ ?>