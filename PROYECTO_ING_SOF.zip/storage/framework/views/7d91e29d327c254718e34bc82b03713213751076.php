<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
 
  <link rel="icon" href="<?php echo e(asset('imagenes/iconos/icono_pagina.ico')); ?>">

  <?php echo $__env->yieldContent('css'); ?>

  <title>Merca-Lin</title>
</head>

<body>
    
  <div class="container-fluid bg-primary p-2">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('pagina_principal')); ?>">Merca-Lin (mercado en línea)</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          </ul>
          <form class="d-flex">
            <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search">
            <button class="btn btn-warning" type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>
      </div>
    </nav>

  </div>

  
  <div class="container-fluid bg-dark p-2">
    <div class="clearfix">

      <div class="float-start">
        <?php echo $__env->yieldContent('START'); ?>
      </div>

      <div class="float-end">
        <?php echo $__env->yieldContent('END'); ?>
      </div>

    </div>
  </div>


  

  <div class="container mt-5">
   
      <?php echo $__env->yieldContent('CONTENIDO'); ?>

  </div>

  <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  
  <?php echo $__env->yieldContent('js'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/plantilla_general.blade.php ENDPATH**/ ?>