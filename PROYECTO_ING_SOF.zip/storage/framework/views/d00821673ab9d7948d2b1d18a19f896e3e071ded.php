<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('imagenes/iconos/icono_pagina.ico')); ?>">
    <title>Merca-Lín</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
 

</head>
<body class="BODY_LOGIN">
    <div id="app">
        <nav class="navbar navbar-expand-md shadow-sm panel_inicial">
            <div class="container-fluid">
                <a class="navbar-brand text-light" href="<?php echo e(route('home')); ?>">
                    <div class="row">
                        <div class="col-2">
                          <h4 class="animate__animated animate__lightSpeedInLeft"><i class="fas fa-shop"></i></h4>
                        </div>
                        <div class="col-2">
                          <h4 class="animate__animated animate__lightSpeedInRight">Merca-Lín</h4>
                          <h6 class="animate__animated animate__lightSpeedInRight" style="margin-top: -9px; margin-left: 28px;"><i class="fas fa-coins"></i> Compras en Línea</h6>
                        </div>
                    </div>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-light" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar Sesión')); ?></a>
                                </li>
                            <?php endif; ?>
                                <h3 class="text-light">|</h3>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-light" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarse')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link text-light dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->nombre_user); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                
                                    <a class="dropdown-item" onClick="history.go(-1);">

                                        <i class="fas fa-sign-out-alt"></i><?php echo e(__('Volver')); ?>

                                    </a>

                                
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <i class="fas fa-sign-out-alt"></i><?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="panel_seccundario">
            <nav class="nav p-2">
                <li class="nav-item MENU">
                    <a class="nav-link text-light" href="<?php echo e(route('pagina_principal')); ?>"><i class="fas fa-home"></i> Inicio</a>
                </li>
            </nav>
        </div>

        <main class="py-5">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <div class="text-center">
        <p class="text-light">@Derechos  Reservados 2022, Merca-Lín</p>
    </div>



    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/layouts/app.blade.php ENDPATH**/ ?>