

<?php $__env->startSection('CSS'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/ribbon.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('START'); ?>
    <nav class="nav">
        <li class="nav-item">
        <a class="nav-link text-light MENU" href="<?php echo e(route('pagina_principal')); ?>"><i class="fas fa-home"></i> Inicio</a>
        </li>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-light MENU" href="#" id="navbarDropdown" role="button"
            data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-bars"></i> Categorías
        </a>
        <ul class="dropdown-menu panel_seccundario" aria-labelledby="navbarDropdown">
        
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><a class="dropdown-item text-light SUB_MENU" href="<?php echo e(route('buscar',['id' => $item->id_categoria, 'tipo_busqueda' => 'C'])); ?>"><?php echo e($item->nombre_categoria); ?></a></li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-light MENU" href="#" id="navbarDropdown" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-plus"></i> Información
            </a>

            <ul class="dropdown-menu panel_seccundario" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item text-light SUB_MENU" target="_blank" href="<?php echo e(route('IR_ACERCA_DE')); ?>"><i class="fas fa-info-circle"></i> Acerca de</a></li>
                <li><a class="dropdown-item text-light SUB_MENU" href="<?php echo e(route('IR_AYUDA')); ?>"><i class="fas fa-question-circle"></i> Ayuda</a></li>
            </ul>
        </li>

    </nav>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('END'); ?>
    <nav class="nav"> 
        <?php if(Auth::guest()): ?>
            <li class="nav-item">
                <a class="nav-link text-light MENU" href="<?php echo e(route('home')); ?>"><i class="fas fa-user-circle"></i> Iniciar Sesión</a>
            </li>    
        <?php else: ?>
            
           <li class="nav-item px-2">
                <a class="btn btn-dark text-light" href="<?php echo e(route('home')); ?>"><i class="fas fa-user-circle"></i> Mi perfil</a>
           </li>

            <li class="nav-item">
                <a class="btn btn-dark text-light position-relative" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                    <i class="fas fa-shopping-cart "></i> 
                    <span class="position-absolute top-0 start-98 translate-middle badge rounded-pill bg-danger">
                        <?php echo e(\Cart::getTotalQuantity()); ?>

                    </span>
                </a>
            </li>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
                <div class="offcanvas-header">
                <h5 id="offcanvasRightLabel">Tu carrito de compras</h5>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <?php echo $__env->make('partials.cart-drop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>  
        <?php endif; ?>    
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('MENSAJE'); ?>
    <?php if(session('mensaje')): ?>
    <div aria-live="polite" aria-atomic="true" class="position-relative" data-bs-delay="100">         
        <div class="toast-container position-absolute top-0 end-0 p-3" style="z-index:11">
            <div class="toast show" role="alert" aria-live="assertive" data-bs-autohide="false" aria-atomic="true">
            
                <div class="toast-header">
                <strong class="me-auto"><i class="fas fa-info-circle text-primary"></i> Notificación</strong>
                <small class="text-muted">justo ahora</small>
                <button type="button" onclick="cerrar()" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                <p class="text-success"><i class="fas fa-check-circle text-success"></i> <?php echo e(session('mensaje')); ?></p>
                </div>
            </div>
        </div>
    </div>
     <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('CONTENIDO'); ?>

    <div class="container">
        <?php echo e($articulos->links('pagination::bootstrap-4')); ?>

    </div>

    <div class="row row-cols-1 row-cols-md-3 p-5">

        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col mb-5">
            <div class="card  carta-producto box">
                
                <?php if($item->obtener_estado_articulo->estado_articulo=="Nuevo"): ?>

                <div class="ribbon-nuevo ribbon-top-left"><span><?php echo e($item->obtener_estado_articulo->estado_articulo); ?></span></div>  
               
                <?php else: ?>
                <div class="ribbon-usado ribbon-top-left"><span><?php echo e($item->obtener_estado_articulo->estado_articulo); ?></span></div>  
                <?php endif; ?>
               
                <div class="card-body mt-1 text-end ">
                    <div class="clearfix">
                        <div class="float-end">
                            <a href="<?php echo e(url('articulos/'.$item->id_articulo)); ?>" class="btn btn-primary">Ver más</a>
                        </div>
                    </div>    
                </div>

               
                <div class="card-body">

                    <div class=" text-center">
                        <div id="v<?php echo e($item->id_articulo); ?>" class="carousel slide" data-bs-ride="carousel">
   
                            <div class="carousel-inner">
                              
                                <?php $__currentLoopData = $item->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img=>$VALOR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($img==0): ?>
                                        <div class="carousel-item active">
                                            <img src="<?php echo e(asset('storage').'/'.$VALOR->ruta_imagen); ?>" class="w-75 IMAGENES">
                                        </div> 
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </div>
                          </div>
                    </div>
                    <hr>
                    <div class="clearfix">
                        <div class="float-start">
                            <p class="text-muted"><b><?php echo e($item->nombre_articulo); ?></b></p>
                        </div>

                        

                        <div class="float-end">
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" value="<?php echo e($item->id_articulo); ?>" id="id" name="id">
                                <input type="hidden" value="<?php echo e($item->nombre_articulo); ?>" id="name" name="name">
                                
                                
                                <?php if($item->descuento!=0): ?>
                                    <?php
                                        $precio=$item->precio;
                                        $descuento=$item->descuento;

                                        $operacion=100-$descuento;
                                        $resultado=$precio*($operacion/100);
                                    ?>

                                    <input type="hidden" value="<?php echo e($resultado); ?>" id="price" name="price">
                                <?php else: ?>    
                                    <input type="hidden" value="<?php echo e($item->precio); ?>" id="price" name="price"> 
                                <?php endif; ?>
                                
                                
                                <?php $__currentLoopData = $item->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img=>$VALOR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($img==0): ?>
                                        <input type="hidden" value="<?php echo e($VALOR->ruta_imagen); ?>" id="img" name="img">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" value="<?php echo e($item->obtener_categoria->nombre_categoria); ?>" id="slug" name="slug">
                                <input type="hidden" value="1" id="quantity" name="quantity">
                                <input type="hidden" value="<?php echo e($item->obtener_user->id_user); ?>" name="owner" id="owner">
                                
                                <button data-bs-toggle="tooltip" data-bs-placement="right" title="añadir al carrito" class="btn btn-sm btn-dark text-light"><i class="fas fa-shopping-cart"></i></button>
                            </form> 
                        </div>

                        

                    </div>
                    <div class="clearfix">
                        <div class="float-start">
                            <?php if($item->descuento!=0): ?>
                                <?php
                                    $precio=$item->precio;
                                    $descuento=$item->descuento;

                                    $operacion=100-$descuento;
                                    $resultado=$precio*($operacion/100);
                                ?>
                
                                <label class="text-muted"><small><b><?php echo e($item->obtener_categoria->nombre_categoria); ?> | </b></small>
                                    <span class="badge bg-danger text-decoration-line-through">$ <?php echo e($precio); ?></span>  
                                    <span class="badge bg-success">$ <?php echo e($resultado); ?></span>
                                </label>
                                <?php else: ?>    
                                <label class="text-muted "><small><b><?php echo e($item->obtener_categoria->nombre_categoria); ?> | </b></small>
                                    <span class="badge bg-success">$ <?php echo e($item->precio); ?></span> 
                                </label>  
                           <?php endif; ?>
                        </div>
                        <div class="float-end">
                            <p class="text-muted mb-0"><small><b>Disponible: <?php echo e($item->cantidad); ?></b></small></p>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="container mt-4 p-2">
        <?php echo e($articulos->links('pagination::bootstrap-4')); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        
        function cerrar(){
            $('.toast').hide();
        }

        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantillas_Generales.plantilla_general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/pagina_principal/index.blade.php ENDPATH**/ ?>