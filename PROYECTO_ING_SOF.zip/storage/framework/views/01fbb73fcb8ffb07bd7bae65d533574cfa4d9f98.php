<div class="modal fade" tabindex="-1"  data-bs-backdrop="static" data-bs-keyboard="false" id="edit_direccion<?php echo e($cliente->id_user); ?>">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-dark text-light">
        <h6 class="modal-title">Estas editando tu dirección <?php echo e($cliente->nombre); ?></h6>
        <button type="button" class="btn text-light" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
      </div>
      <div class="modal-body">
        
        <form action="<?php echo e(url('direcciones/'.$cliente->id_user)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <?php $__currentLoopData = $cliente->obtener_direccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
            <div class="input-group mb-3">
              <span class="input-group-text">Código Postal: </span>
              <input type="number" name="codigo_postal" value="<?php echo e($item->codigo_postal); ?>" class="form-control">
            </div>

            <div class="input-group mb-3">
              <span class="input-group-text">País: </span>
              <input type="text" name="pais" value="<?php echo e($item->pais); ?>" class="form-control">
            </div>

            <div class="input-group mb-3">
              <span class="input-group-text">Provincia: </span>
              <select name="provincia" class="form-select">
                <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prov); ?>" <?php echo e(($prov==$item->provincia)?'selected':''); ?> ><?php echo e($prov); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="input-group mb-3">
              <span class="input-group-text">Ciudad: </span>
              <input type="text" name="ciudad" value="<?php echo e($item->ciudad); ?>" class="form-control">
            </div>

            <div class="input-group mb-3">
              <span class="input-group-text">Dirección Actual: </span>
              <input type="text" name="direccion_actual" value="<?php echo e($item->direccion_actual); ?>" class="form-control">
            </div>

            <div class="text-end">
              <button class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Actualizar</button>
              <button type="button" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Cancelar</button>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </form>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/modales/modal_edit_direccion.blade.php ENDPATH**/ ?>