

<?php $__env->startSection('FOTO-DE-PERFIL'); ?>
<a class="navbar-brand ps-1" href="<?php echo e(route ('home')); ?>"> <img class="rounded-circle w-25 p-2" src="<?php echo e(asset('storage'.'/'.$cliente->foto_perfil)); ?>" alt=""> <span class="badge bg-success"><?php echo e(Auth::user()->nombre); ?></span></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('TITULO'); ?>
    <title>Tu Perfil</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('DROPDOWN'); ?>
    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
    aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
    <ul class="dropdown-menu dropdown-menu-end bg-dark" aria-labelledby="navbarDropdown">
        
        <li>
            <form action="<?php echo e(url('user/'.Auth::user()->id_user)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('GET'); ?>

                <button type="submit" class="dropdown-item text-light">
                    <i class="fas fa-user"></i> Mi Perfil
                </button>
            </form>
        </li>
        
        <li>
            <hr class="dropdown-divider" />
        </li>
        <li><a class="dropdown-item text-light" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
            
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('MENU-LATERAL'); ?>    
  <?php if(Auth::user()->membresia=="si"): ?>
  <div class="sb-sidenav-menu-heading">¿Qué deseas realizar?</div>
  <a class="nav-link" href="<?php echo e(url('articulos/create')); ?>">
      <div class="sb-nav-link-icon"><i class="fas fa-upload"></i></div>
      Publicar Artículo
  </a>

  <a class="nav-link" href="<?php echo e(route('home')); ?>">
  <div class="sb-nav-link-icon"><i class="fas fa-eye"></i></div>
      Ver Artículos
  </a>

  <div class="sb-sidenav-menu-heading">Sección de entregas y compras</div>
  <a class="nav-link" href="<?php echo e(route('ENTREGAS')); ?>">
      <div class="sb-nav-link-icon"><i class="fas fa-handshake"></i></div>
      Entregas
  </a>

  <a class="nav-link" href="<?php echo e(route('MIS_COMPRAS')); ?>">
  <div class="sb-nav-link-icon"><i class="fas fa-credit-card"></i></div>
      Mis compras
  </a>

  <?php else: ?>
  <div class="sb-sidenav-menu-heading">¿Qué deseas realizar?</div>
  <a class="nav-link" href="<?php echo e(route('home')); ?>">
      <div class="sb-nav-link-icon"><i class="fas fa-eye"></i></div>
      Mis Compras
  </a>
  <?php endif; ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('CONTENIDO'); ?>

    <?php if(session('mensaje')): ?>
    <div aria-live="polite" aria-atomic="true" class="position-relative" data-bs-delay="100">
                
        <div class="toast-container position-absolute top-0 end-0 p-3" style="z-index:11">

            <div class="toast show" role="alert" aria-live="assertive" data-bs-autohide="false" aria-atomic="true">
                <div class="toast-header">
                <strong class="me-auto"><i class="fas fa-info-circle text-primary"></i> Notificación</strong>
                <small class="text-muted">justo ahora</small>
                <button type="button" onclick="cerrar()" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                <p class="text-success"><i class="fas fa-check-circle text-success"></i> <?php echo e(session('mensaje')); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="container mt-5">
        <div class="container">
            <div class="main-body">
          
                  <div class="row gutters-sm">
                    <div class="col-md-4 mb-3">

                      <div class="card shadow">
                        <div class="card-body">
                          <div class="d-flex flex-column align-items-center text-center">
                            <img src="<?php echo e(asset('storage').'/'.$cliente->foto_perfil); ?>" class="rounded-circle" width="150">
                            <div class="mt-3">
                              <h4><?php echo e($cliente->nombre_user); ?></h4>

                              <?php if($cliente->id_tipo_cuenta==1): ?>
                              <p class="text-secondary mb-1">Vendedor(a) en la página Merca-Lín</p>
                              <?php else: ?>
                              <p class="text-secondary mb-1">Comprador(a) en la página Merca-Lín</p>
                              <?php endif; ?>
                              <?php $__currentLoopData = $cliente->obtener_direccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <p class="text-muted font-size-sm"><?php echo e($item->pais); ?>, <?php echo e($item->provincia); ?>, <?php echo e($item->ciudad); ?></p> 
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <a class="btn btn-secondary btn-sm" href="<?php echo e(route('password.request')); ?>">
                                Cambiar contraseña
                              </a>

                              <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#edit_user<?php echo e($cliente->id_user); ?>">Editar</button>
                              <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#eliminar_perfil<?php echo e($cliente->id_user); ?>">Eliminar</button>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="card mt-3 shadow">
                        <ul class="list-group list-group-flush">
                          <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                            <h6 class="mb-0"><i class="fas fa-check"></i> Total de Artículos Publicados</h6>
                              <span class="text-secondary"><?php echo e($total_mis_art_publicados); ?></span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                            <h6 class="mb-0"><i class="fas fa-check"></i> Total de Articulos Vendidos</h6>
                            <span class="text-secondary"><?php echo e($total_vendidos); ?></span>
                          </li>
                          <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                            <h6 class="mb-0"><i class="fas fa-coins"></i> Ganancia en Ventas</h6>
                            <span class="text-secondary">$ <?php echo e($cliente->ganancias); ?></span>
                          </li>
                        </ul>
                      </div>

                    </div>

                    <div class="col-md-8">
                      <div class="card mb-3 shadow">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-sm-3">
                              <h6 class="mb-0">Nombre completo</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                                <?php echo e($cliente->nombre); ?> <?php echo e($cliente->primer_apellido); ?> <?php echo e($cliente->segundo_apellido); ?>

                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-sm-3">
                              <h6 class="mb-0">Correo</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                              <?php echo e($cliente->email); ?>

                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-sm-3">
                              <h6 class="mb-0">Teléfono</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                              (506) <?php echo e($cliente->telefono); ?>

                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-sm-3">
                              <h6 class="mb-0">Fecha de Registro</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                              <?php echo e($cliente->fecha_registro); ?>

                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-sm-3">
                              <h6 class="mb-0">Dirección</h6>
                            </div>
                            <div class="col-sm-9 text-secondary">
                               <?php $__currentLoopData = $cliente->obtener_direccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php echo e($item->provincia); ?>, <?php echo e($item->ciudad); ?> <?php echo e($item->direccion_actual); ?>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                          </div>
                          <hr>
                          <div class="row">
                            <div class="col-sm-12">
                              <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#edit_direccion<?php echo e($cliente->id_user); ?>">Editar Dirección</button>
                             
                            </div>
                          </div>
                        </div>
                      </div>
        
                      <div class="row gutters-sm">
                        <div class="col-sm-6 mb-3">
                          <div class="card h-100 shadow">
                            <div class="card-body text-center">
                              <?php if($cliente->membresia == "si"): ?>
                          
                                <?php
                                  date_default_timezone_set('America/Costa_Rica');

                                  $fechaAct= new DateTime(date('Y-m-d')); 
                                  $fechaRenov= new DateTime($cliente->fecha_renovacion);
                                  
                                  $dias = $diff = $fechaAct->diff($fechaRenov); 

                                  $dias = $fechaAct->diff($fechaRenov)->format('%r%a');
                                ?>
                                <span style="font-size: 19px" class="badge bg-success">Membresía expira en <?php echo e($dias); ?> días</span>
                              <?php else: ?>
                              <span style="font-size: 19px" class="badge bg-warning">No paga</span>
                              <?php endif; ?>
                              
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6 mb-3">
                          <div class="card h-100 shadow">
                            <div class="card-body text-center">

                              <form target="__blank" action="<?php echo e(route('MIS_ART_VENDIDOS')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('GET'); ?>
                                <input type="hidden" name="array_art_vendidos" value="<?php echo e($vendidos); ?>">
                                <input type="hidden" name="total_vendidos" value="<?php echo e($total_vendidos); ?>">
                                <button class="btn btn-danger">Lista de artículos vendidos PDF</button>
                              </form>

                             
                            </div>
                          </div>
                        </div>
                      </div>
 
                    </div>
                  </div>
        
                </div>
            </div>
    </div>
    
    <div>
      <?php echo $__env->make('modales.modal_edit_direccion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div>
      <?php echo $__env->make('modales.modal_edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div>
      <?php echo $__env->make('alertas.modal_eliminar_perfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>



    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function cerrar(){
            $('.toast').hide();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantillas_Generales.plantilla_general_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/Gestionar_perfil/index_perfil.blade.php ENDPATH**/ ?>