


<?php $__env->startSection('START'); ?>
    <nav class="nav">
        <li class="nav-item">
        <a class="nav-link text-light MENU" href="<?php echo e(route('pagina_principal')); ?>"><i class="fas fa-home"></i> Inicio</a>
        </li>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-light MENU" href="#" id="navbarDropdown" role="button"
            data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-bars"></i> Categorías
        </a>
        <ul class="dropdown-menu panel_seccundario" aria-labelledby="navbarDropdown">
           <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><a class="dropdown-item text-light SUB_MENU" href="<?php echo e(route('buscar',['id' => $item->id_categoria, 'tipo_busqueda' => 'C'])); ?>"><?php echo e($item->nombre_categoria); ?></a></li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </li>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-light MENU" href="#" id="navbarDropdown" role="button"
            data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fas fa-plus"></i> Información
        </a>

        <ul class="dropdown-menu panel_seccundario" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item text-light SUB_MENU" target="_blank" href="<?php echo e(route('IR_ACERCA_DE')); ?>"><i class="fas fa-info-circle"></i> Acerca de</a></li>
            <li><a class="dropdown-item text-light SUB_MENU" href="<?php echo e(route('IR_AYUDA')); ?>"><i class="fas fa-question-circle"></i> Ayuda</a></li>
        </ul>
        </li>
    </nav>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('END'); ?>
    <nav class="nav"> 
        <li class="nav-item">
            <a class="nav-link text-light MENU" href="<?php echo e(route('home')); ?>"><i class="fas fa-user-circle"></i> Iniciar Sesión</a>
        </li>
    </nav>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('CONTENIDO'); ?>
   <div class="text-center mt-5">

    <?php if($mensaje!=null): ?>
    <h5 class="text-danger mb-5">
        <?php echo e($mensaje); ?>

    </h5>
    <?php endif; ?>

    <img src="<?php echo e(asset('imagenes_error/error.png')); ?>" alt="">
    <img src="<?php echo e(asset('imagenes_error/404.png')); ?>" alt=""> 
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantillas_Generales.plantilla_general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/ERROR/error_busqueda.blade.php ENDPATH**/ ?>