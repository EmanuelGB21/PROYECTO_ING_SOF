<div class="modal fade" tabindex="-1" id="mas_info">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-dark text-light">
          <h5 class="modal-title">Solo falta un paso más</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

          <p>FORMULARIO PARA DIRECCIÓN</p>
          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary"><i class="fas fa-save"></i> Registrarse</button>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/modales/modal_registro_cuenta.blade.php ENDPATH**/ ?>