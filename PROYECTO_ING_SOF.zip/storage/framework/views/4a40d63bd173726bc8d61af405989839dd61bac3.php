<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <title>Document</title>
    </head>
    <body>

        <?php if($mensaje['estado']=="registrarse"): ?>

        <p>BIENVENIDO A NUESTRA PÁGINA WEB, ESPERAMOS QUE TU ESTADÍA SEA LA MEJOR</p>
        <h4>....</h4>
        <p> Tu nombre de usuario es: <?php echo e($mensaje['nombre_user']); ?></p>

        <p> Tu contraseña para acceder a tu perfil es: <?php echo e($mensaje['password']); ?></p>

        <p>* Puedes cambiar tu contraseña cuando quieras.</p>

        <p>No compartas con nadie esta información, es solo para uso personal</p>
        <?php endif; ?>

        <?php if($mensaje['estado']=="reportada"): ?>
            <p>Hola, <?php echo e($mensaje['nombre']); ?> <?php echo e($mensaje['primer_apellido']); ?> <?php echo e($mensaje['segundo_apellido']); ?></p>
            <p>El artículo <?php echo e($mensaje['nombre_articulo']); ?> fue reportado como posible estafa</p>
            <p><?php echo e($mensaje['contenido']); ?></p>
        <?php endif; ?>

        <?php if($mensaje['estado']=="membresia"): ?>
        <p>Hola, <?php echo e($mensaje['nombre_completo']); ?></p>    
        <p><?php echo e($mensaje['contenido']); ?></p>
        <p><?php echo e($mensaje['contenido_2']); ?></p>
        <p>La compra fue realizada el <?php echo e($mensaje['fecha_de_pago_inicial']); ?></p>
        <p>*<b>Recuerda que la membresía la tienes que renovar cada mes por el mismo monto</b></p>
        
        <?php endif; ?>

        <?php if($mensaje['estado']=="contactar"): ?>
            <p><?php echo e($mensaje['contenido']); ?></p>  
        <?php endif; ?>

        <?php if($mensaje['estado']=="compra_articulos"): ?>

        <p><?php echo e($mensaje['contenido']); ?></p>  
        <p>Gracias por utlizar nuestro servicios</p>
    <?php endif; ?>
    
        
    </body>
</html><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/plantilla_correos/mail_registro.blade.php ENDPATH**/ ?>