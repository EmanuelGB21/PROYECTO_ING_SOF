<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color: rgba(47, 46, 46, 0.358)">
                <div class="card-header bg-dark text-center text-light"><i class="fas fa-warning"></i> <?php echo e(__('Por favor llena los campos con los datos solicitados')); ?> <i class="fas fa-warning"></i></div>

                <div class="card-body">
                    <form class="text-light" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="parte_1_registro">

                            <input type="hidden" name="estado_cuenta" value="1">
                            <input type="hidden" name="id_tipo_cuenta" value="3">
                            <input type="hidden" name="membresia" value="no">

                            <input type="hidden" name="nombre_user" id="nombre_user">


                            
                            <div class="row mb-3 mt-2">
                                <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nombre')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" placeholder="Ingresa tu Nombre" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label for="primer_apellido" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Primer Apellido')); ?></label>

                                <div class="col-md-6">
                                    <input id="primer_apellido" type="text" placeholder="Ingresa tu Primer Apellido" class="form-control <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="primer_apellido" value="<?php echo e(old('primer_apellido')); ?>" required autocomplete="primer_apellido" autofocus>

                                    <?php $__errorArgs = ['primer_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
                            

                            <div class="row mb-3">
                                <label for="segundo_apellido" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Segundo Apellido')); ?></label>

                                <div class="col-md-6">
                                    <input id="segundo_apellido" type="text" placeholder="Ingresa tu Segundo Apellido" class="form-control <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="segundo_apellido" value="<?php echo e(old('segundo_apellido')); ?>" required autocomplete="segundo_apellido" autofocus>

                                    <?php $__errorArgs = ['segundo_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Correo electrónico')); ?></label>

                                <div class="col-md-6">
                                    <input id="email" type="email" placeholder="Ingresa tu correo con formato: @gmail.com" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            
                            <div class="row mb-3">
                                <label for="telefono" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Teléfono')); ?></label>

                                <div class="col-md-6">
                                    <input id="telefono" type="number" placeholder="Ingresa tu Número Telefónico" class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required autocomplete="telefono">

                                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="row">
                                <div class="text-center">
                                    <button class="btn btn-primary" onclick="getNameUser()">
                                        <i class="fas fa-save"></i> <?php echo e(__('Registrarse')); ?>

                                    </button>
                                </div>
                            </div>

                        </div>
                       
                    </form>
                </div>
            </div>         
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $('.parte_1_registro').show();
        $('.parte_2_registro').hide();

        $("#btn_siguiente_paso").on('click', function(){
            $('.parte_1_registro').hide();
            $('.parte_2_registro').show();
        });

        $("#btn_volver").on('click', function(){
            $('.parte_1_registro').show();
            $('.parte_2_registro').hide();
        });
          
        function getNameUser(){
        var cadena0 = document.getElementById('name').value;
        var cadena1 = document.getElementById('primer_apellido').value;
        var cadena2 = document.getElementById('segundo_apellido').value;

        $("#nombre_user").val(cadena0.substr(0,3)+cadena1.substr(0,4)+cadena2);
        }
        
        /** document.form.nombre_input.value = lo que quiero que vaya */

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/auth/register.blade.php ENDPATH**/ ?>