<div class="modal fade" id="car_del<?php echo e($item->id); ?>"  data-backdrop="static" data-keyboard="false" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="text-center">
                    <h2 class="text-warning"><i class="fa fa-exclamation-triangle"></i> </h2>
                    <h6 class="mt-4">
                        ¿Deseas eliminar tu carrito de compras?
                    </h6>
                    <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                       
                        <div class="text-end mt-4">
                            <button class="btn btn-primary btn-sm">Sí, eliminar</button> 
                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Cancelar</button>
                        </div>
                    </form>       
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/carrito/modal_borrar_carrito.blade.php ENDPATH**/ ?>