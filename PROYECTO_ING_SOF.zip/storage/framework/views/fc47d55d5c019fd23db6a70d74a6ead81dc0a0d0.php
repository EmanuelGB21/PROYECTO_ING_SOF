<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>