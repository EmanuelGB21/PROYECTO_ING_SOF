

<?php $__env->startSection('START'); ?>
    <nav class="nav">
        <li class="nav-item">
        <a class="nav-link text-light MENU" href="<?php echo e(route('pagina_principal')); ?>"><i class="fas fa-home"></i> Inicio</a>
        </li>
    </nav>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('END'); ?>
    <nav class="nav">
      <?php if(Auth::guest()): ?>
        <li class="nav-item">
          <a class="nav-link text-light MENU" href="<?php echo e(route('home')); ?>"><i class="fas fa-user-circle"></i> Iniciar Sesión</a>
        </li>  
      <?php else: ?>
      <a class="btn btn-dark text-light position-relative" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
        <i class="fas fa-shopping-cart "></i> 
        <span class="position-absolute top-0 start-98 translate-middle badge rounded-pill bg-danger">
            <?php echo e(\Cart::getTotalQuantity()); ?>

        </span>
      </a>

      <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
          <div class="offcanvas-header">
          <h5 id="offcanvasRightLabel">Tu carrito de compras</h5>
          <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
              <?php echo $__env->make('partials.cart-drop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>
      <?php endif; ?>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('CONTENIDO'); ?>
    
<div class="clearfix">
    <div class="float-start">
      <!-- DATOS DEL ARTÍCULO -->

      <div class="card mb-3 carta-producto" id="tamaño_reportar_y_detalles_articulos">
        <div class="card-header bg-dark">

          <div class="row align-items-center">

            <div class="col mt-1">
              <a href="<?php echo e(route('pagina_principal')); ?>" class="btn btn-danger"><i class="fas fa-arrow-left"></i></a>
            </div>

            <div class="col text-center mt-1">
              <h5 class="text-light"><i class="fas fa-clipboard"></i> Detalles del Producto</h5>
            </div>

            <div class="col text-end">
             
              <a target="_blank" href="<?php echo e(route('GENERAR_PDF',$articulo->id_articulo)); ?>" class="btn btn-danger">PDF <i class="fas fa-download"></i></a>

            </div>

          </div>
        </div>
        <div class="row g-0">
          <div class="col-md-6">
            <!--INICIA CAROUSEL -->
            <div id="img<?php echo e($articulo->id_articulo); ?>" class="carousel slide carousel-fade" data-bs-ride="carousel">

              <div class="carousel-indicators">
                <?php $__currentLoopData = $articulo->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($valor==0): ?>
                    <button type="button" data-bs-target="#img<?php echo e($articulo->id_articulo); ?>" data-bs-slide-to="<?php echo e($loop->index); ?>" class="active"
                    aria-current="true" aria-label="Slide <?php echo e($loop->index); ?>"></button>
                  <?php else: ?>  
                  <button type="button" data-bs-target="#img<?php echo e($articulo->id_articulo); ?>" data-bs-slide-to="<?php echo e($loop->index); ?>" aria-label="Slide <?php echo e($loop->index); ?>"></button>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <div class="carousel-inner">
                
                <?php $__currentLoopData = $articulo->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor=>$img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($valor==0): ?>
                      <div class="carousel-item active">
                        <div
                          style="width: 100%; height:280px; background-image: url('<?php echo e(asset('storage').'/'.$img->ruta_imagen); ?>'); background-repeat: no-repeat;background-size: cover;">
                        </div>
                      </div>
                    <?php else: ?>
                      <div class="carousel-item">
                        <div
                          style="width: 100%; height:280px; background-image: url('<?php echo e(asset('storage').'/'.$img->ruta_imagen); ?>'); background-repeat: no-repeat;background-size: cover;">
                        </div>
                      </div>   
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <button class="carousel-control-prev" type="button" data-bs-target="#img<?php echo e($articulo->id_articulo); ?>"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#img<?php echo e($articulo->id_articulo); ?>"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>

            <!--  CIERRA CAROUSEL -->

            
            <div class="p-2 mt-2">
              <p class="card-text"><small class="text-muted"><b><i class="fas fa-calendar-alt"></i>
                Fecha de publicación: <?php echo e($articulo->fecha_publicacion_articulo); ?>

              </b></small></p>
                             
              <?php if($articulo->id_estado_articulo==1): ?>
              <p class="card-text"><b>Estado:</b> <span class="badge bg-success text-uppercase"><?php echo e($articulo->obtener_estado_articulo->estado_articulo); ?></span></p>    
              <?php else: ?>
              <p class="card-text"><b>Estado:</b> <span class="badge bg-warning text-light text-uppercase"><?php echo e($articulo->obtener_estado_articulo->estado_articulo); ?></span></p>    
              <?php endif; ?>
              
            </div>
            
          </div>

          <div class="col-md-6">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($articulo->nombre_articulo); ?> | <?php echo e($articulo->obtener_categoria->nombre_categoria); ?></h5>

              
              <div class="clearfix">
                <div class="float-start">
                  <?php if($articulo->descuento!=0): ?>
                  <?php
                      $precio=$articulo->precio;
                      $descuento=$articulo->descuento;

                      $operacion=100-$descuento;
                      $resultado=$precio*($operacion/100);
                  ?>
  
                  <h6 class="text-start mt-3">Precio : 
                      <span class="badge bg-danger text-decoration-line-through">$ <?php echo e($precio); ?></span>  
                      <span class="badge bg-success">$ <?php echo e($resultado); ?></span>
                  </h6>
                  
                <?php else: ?>
                  
                  <h6 class="text-start mt-3"> Precio : 
                      <span class="badge bg-success">$ <?php echo e($articulo->precio); ?></span> 
                  </h6>  

              <?php endif; ?>
                </div>
                <div class="float-end">
                  <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" value="<?php echo e($articulo->id_articulo); ?>" id="id" name="id">
                    <input type="hidden" value="<?php echo e($articulo->nombre_articulo); ?>" id="name" name="name">
                    
                    
                    <?php if($articulo->descuento!=0): ?>
                        <?php
                            $precio=$articulo->precio;
                            $descuento=$articulo->descuento;

                            $operacion=100-$descuento;
                            $resultado=$precio*($operacion/100);
                        ?>

                        <input type="hidden" value="<?php echo e($resultado); ?>" id="price" name="price">
                    <?php else: ?>    
                        <input type="hidden" value="<?php echo e($articulo->precio); ?>" id="price" name="price"> 
                    <?php endif; ?>
                    
                    
                    <?php $__currentLoopData = $articulo->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img=>$VALOR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($img==0): ?>
                            <input type="hidden" value="<?php echo e($VALOR->ruta_imagen); ?>" id="img" name="img">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" value="<?php echo e($articulo->obtener_categoria->nombre_categoria); ?>" id="slug" name="slug">
                    <input type="hidden" value="1" id="quantity" name="quantity">
                    <input type="hidden" value="<?php echo e($articulo->obtener_user->id_user); ?>" name="owner" id="owner">
                    
                    <button data-bs-toggle="tooltip" data-bs-placement="right" title="añadir al carrito" class="btn btn-sm btn-dark text-light"><i class="fas fa-shopping-cart"></i></button>
                </form> 
                </div>
              </div>
              

              <p class="mt-5"><b><u>Descripción:</u></b></p>

              <p class="card-text"><?php echo e($articulo->descripcion); ?></p>
            </div>

            <div class="card-body  mt-4 text-end">
              <label style="font-size:17px;"><i class="fas fa-share"></i><b> Compartir con:</b></label>

                <a href="https://api.whatsapp.com/send?text=<?php echo e(Request::fullUrl()); ?>" target="__blank"><i style="font-size:20px; color:rgb(31, 179, 92)"
                    class="fab fa-whatsapp-square"></i></a>
                <a href="http://www.facebook.com/sharer.php?u=<?php echo e(Request::fullUrl()); ?>&t=pagina de desarrollo web" target="__blank"><i style="font-size:20px; color:rgb(66, 103, 178)"
                    class="fab fa-facebook-square"></i></a>
                <a href="https://twitter.com/intent/tweet?text=MIEpresa&url=<?php echo e(Request::fullUrl()); ?>&via=Empresa&hashtags=#miempresa" target="__blank"><i style="font-size:20px; color:rgb(29, 161, 242)"
                    class="fab fa-twitter-square"></i></a>
            </div>

          </div>
        </div>
      </div>


      

      <div class="container gallery-container mt-2 mb-5" id="tamaño_reportar_y_detalles_articulos">
        <h2>Fotografías</h2>
        <div class="tz-gallery">
          <div class="row">
            <?php $__currentLoopData = $articulo->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-2 mb-4">
                <a class="lightbox" href="#!" data-bs-toggle="modal" data-bs-target="#my_modal<?php echo e($loop->index); ?>">
                  <img class="w-100 mb-4 rounded" src="<?php echo e(asset('storage'.'/'.$img->ruta_imagen)); ?>">
                </a>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>

    </div> <!-- FIN DATOS DEL ARTÍCULO -->

    <div class="float-end">
      <!-- DATOS DEL PROPIETARIO -->
      <div class="card ficha_propietario">
        <div class="card-header text-center">
          <img class="rounded-circle w-75" src="<?php echo e(asset('storage').'/'.$articulo->obtener_user->foto_perfil); ?>" alt="">
        </div>
        <div class="card-body">
          <p class="card-title text-muted mb-3"><strong>Dueño: <?php echo e($articulo->obtener_user->nombre); ?> <?php echo e($articulo->obtener_user->primer_apellido); ?> <?php echo e($articulo->obtener_user->segundo_apellido); ?></strong></p>
          
            <a target="__blank" href="https://api.whatsapp.com/send?phone=506<?php echo e($articulo->obtener_user->telefono); ?>&text=Hola <?php echo e($articulo->obtener_user->nombre); ?>, quisiera saber más detalles de un articulo publicado en la página Merca-Lín" class="card-text"><i style="font-size:17px; color:rgb(31, 179, 92)" class="fab fa-whatsapp-square"></i>
            <b>Contactar por WhatsApp</b></a>
            

            <div class="container-fluid mt-3">
              <a style="font-size: 15px" href="">Ver más articulos del dueño</a>
            </div>
          
        </div>
      </div>

      <div class="card-header reportar-publicacion mt-2">
          <div class="form-inline">
            <label class="text-center p-2"><b>Reportar Publicación</b></label>
            <button data-bs-toggle="modal" data-bs-target="#reportar<?php echo e($articulo->id_articulo); ?>" class="btn btn-danger btn-sm"><i class="fas fa-info-circle"></i></button>
          </div>
      </div>

    </div> <!-- FIN DATOS DEL PROPIETARIO -->
  </div>

  
  <br><br>

  
  <?php $__currentLoopData = $articulo->obtener_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div id="my_modal<?php echo e($loop->index); ?>" class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="my_modal<?php echo e($loop->index); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <img class="w-50" src="<?php echo e(asset('storage'.'/'.$item->ruta_imagen)); ?>" alt="">
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div>
    <?php echo $__env->make('alertas.report_articulo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  <script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Plantillas_Generales.plantilla_general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/pagina_principal/ver_mas.blade.php ENDPATH**/ ?>