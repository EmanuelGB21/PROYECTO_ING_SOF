<div class="modal fade" id="edit_user<?php echo e($cliente->id_user); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-dark text-light">
          <h6 class="modal-title">Estas editando tu usuario: <?php echo e($cliente->nombre); ?></h6>
          <button type="button" class="btn text-light" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">

          <form action="<?php echo e(url('user/'.$cliente->id_user)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
              <div class="col-sm-5">
                <div class="profile-img mb-3">
                  <img class="rounded-circle" src="<?php echo e(asset('storage'.'/'.$cliente->foto_perfil)); ?>">
                  <div class="file btn-lg btn-secondary">
                    <i class="fas fa-camera"></i>
                    <input type="file" accept="image/*" name="foto_perfil">
                  </div>
                </div>
              </div>

              <div class="col-sm-7">
                <div class="input-group mb-3">
                  <span class="input-group-text">Nombre</span>
                  <input type="text" name="nombre" value="<?php echo e($cliente->nombre); ?>" aria-label="Nombre" class="form-control">
                </div>
    
                <div class="input-group mb-3">
                  <span class="input-group-text">Primer y Segundo Apellido</span>
                  <input type="text" name="primer_apellido" value="<?php echo e($cliente->primer_apellido); ?>" aria-label="Primer Apellido" class="form-control">
                  <input type="text" name="segundo_apellido" value="<?php echo e($cliente->segundo_apellido); ?>" aria-label="Segundo Apellido" class="form-control">
                </div>
    
                <div class="input-group mb-3">
                  <span class="input-group-text">Teléfono</span>
                  <input type="text" name="telefono" value="<?php echo e($cliente->telefono); ?>" aria-label="Telefono" class="form-control">
                </div>
    
                <div class="input-group mb-3">
                  <span class="input-group-text">Correo</span>
                  <input type="text" name="email" value="<?php echo e($cliente->email); ?>" aria-label="Correo" class="form-control">
                </div>
              </div>
            </div>
          
            
            <div class="text-end">
              <button class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Actualizar</button>
              <button type="button" class="btn btn-danger btn-sm" data-bs-dismiss="modal">Cancelar</button>
            </div>
          </form>
  
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/modales/modal_edit_user.blade.php ENDPATH**/ ?>