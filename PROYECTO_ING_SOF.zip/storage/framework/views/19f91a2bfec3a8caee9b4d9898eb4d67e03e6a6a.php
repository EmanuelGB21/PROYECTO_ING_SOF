<div class="modal fade" id="det_fact_compr<?php echo e($item->id_factura); ?>"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      
      <div class="modal-header bg-dark text-light px-0 py-0">
        <p class="modal-title w-100 text-center"> 
          <i class="fas fa-receipt"></i> <?php echo e($item->obtener_user->nombre); ?> tus detalles de tu factura con ID <?php echo e($item->id_factura); ?> son:
        </p>
        <button type="button" class="btn text-light" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
      </div>
      
      <div class="modal-body">
        <?php
            $cont=1;
            $total=0;
        ?>
        <?php $__currentLoopData = $item->obtener_detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalles_factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container-fluid">
          <div class="clearfix">
            <div class="float-start">

              <p style="font-size: 14px">
                <span class="badge bg-secondary rounded-circle"><?php echo e($cont); ?></span> 
                Pertenece a la categoria <?php echo e($detalles_factura->categoria_articulo); ?>

                -> <?php echo e($detalles_factura->nombre_articulo); ?>

                $ <?php echo e($detalles_factura->precio_articulo); ?>

                cantidad: <?php echo e($detalles_factura->cantidad_comprada); ?>

              </p>

            </div>

            <div class="float-end">
              <?php if($detalles_factura->estado_entrega == 0): ?>
                <span style="font-size:12px" class="badge bg-danger">En entrega</span>
              <?php endif; ?>

              <?php if($detalles_factura->estado_entrega == 1): ?>
                <span style="font-size:12px" class="badge bg-primary">Enviado</span>
              <?php endif; ?>

              <?php if($detalles_factura->estado_entrega == 2): ?>
                <span style="font-size:12px" class="badge bg-success">Entregado</span>
              <?php endif; ?>    
            </div>
          </div>

            <?php
                $cont++;
                $total += $detalles_factura->cantidad_comprada*$detalles_factura->precio_articulo;
            ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="card-footer text-end border-dark border-1">
          <p style="font-size: 15px" ><b>Total:</b> <span style="font-size: 15px" class="badge bg-success">$ <?php echo e($total); ?></span></p>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/modales/modal_comprador_detalle_factura.blade.php ENDPATH**/ ?>