<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Perfil o Admin</title>

    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"
        crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-1" href="<?php echo e(route ('IR_ADMIN')); ?>"> <img class="rounded-circle w-25 p-2" src="<?php echo e(asset('imagenes/yo.jpg')); ?>" alt=""> <span class="text-decoration-underline">Emanuel GB</span></a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i
                class="fas fa-bars"></i></button>

        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Buscar Artículo" aria-label="Search for..."
                    aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i
                        class="fas fa-search"></i></button>
            </div>
        </form>

        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown"
                    aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#!"><i class="fas fa-user"></i> Perfil</a></li>
                    <li><a class="dropdown-item" href="#!"><i class="fas fa-user-times"></i> Borrar Cuenta</a></li>
                    <li>
                        <hr class="dropdown-divider" />
                    </li>
                    <li><a class="dropdown-item" href="<?php echo e(route('pagina_principal')); ?>"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>


    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">¿Qué deseas realizar?</div>
                        <a class="nav-link" href="<?php echo e(route('register_article')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-upload"></i></div>
                            Publicar Artículo
                        </a>

                        <a class="nav-link" href="<?php echo e(route('IR_ADMIN')); ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-eye"></i></div>
                            Ver Artículos
                        </a>

                    </div>
                </div>
            </nav>

        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Registrar Artículo</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Sección de registro de articulos <i class="fas fa-arrow-down"></i></li>
                    </ol>

                    <div class="container p-4 mt-2">
                        <div class="row">
                            <div class="col-2"></div>
                            <div class="col-8">
                                <div class="card">
                                    <div class="card-header text-light bg-dark text-center">
                                    
                                        <div class="row">
                                            <div class="col text-start">
                                                <a class="btn btn-danger" href="<?php echo e(route('IR_ADMIN')); ?>"><i class="fas fa-arrow-left"></i></a>
                                            </div>

                                            <div class="col mt-2">
                                               <h5> <i class="fas fa-clipboard"></i> Registrar Artículo</h5>
                                            </div>

                                            <div class="col">

                                            </div>
                                        </div>

                                    </div>
                                    <div class="card-body">
                                     
                                     <form class="row g-3">
                                         <div class="col-md-6">
                                           <label for="inputEmail4" class="form-label">Email</label>
                                           <input type="email" class="form-control" id="inputEmail4">
                                         </div>
                                         <div class="col-md-6">
                                           <label for="inputPassword4" class="form-label">Password</label>
                                           <input type="password" class="form-control" id="inputPassword4">
                                         </div>
                                         <div class="col-12">
                                           <label for="inputAddress" class="form-label">Address</label>
                                           <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
                                         </div>
                                         <div class="col-12">
                                           <label for="inputAddress2" class="form-label">Address 2</label>
                                           <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
                                         </div>
                                         <div class="col-md-6">
                                           <label for="inputCity" class="form-label">City</label>
                                           <input type="text" class="form-control" id="inputCity">
                                         </div>
                                         <div class="col-md-4">
                                           <label for="inputState" class="form-label">State</label>
                                           <select id="inputState" class="form-select">
                                             <option selected>Choose...</option>
                                             <option>...</option>
                                           </select>
                                         </div>
                                         <div class="col-md-2">
                                           <label for="inputZip" class="form-label">Zip</label>
                                           <input type="text" class="form-control" id="inputZip">
                                         </div>

                                         <div class="col-12 text-center">
                                           <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Registrar</button>
                                         </div>
                                       </form>
                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>

                </div>
            </main>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\PROYECTO_INGENIERIA_DE_SOFTWARE\PROYECTO_ING_SOF\resources\views/registrar_articulo.blade.php ENDPATH**/ ?>